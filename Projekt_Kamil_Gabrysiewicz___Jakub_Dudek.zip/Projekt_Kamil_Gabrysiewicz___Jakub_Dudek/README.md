
# Zestawienie danych statystycznych dotyczących gier na platformach Steam i Epic Games Store

## Projekt:
- realizowany w grupach dwuosobowych
- należy wykonać w technologiach przedstawionych w skrypcie
- należy zaprezentować prowadzącemu i przesłać w terminie do przedostatnich zajęć włącznie
- integrowane dane przechowywane w plikach lub bazie danych muszą być zgodne z tematyką projektu
- wymagany jest interfejs graficzny pozwalający na wykonywanie akcji oraz prezentację danych
- Poniżej przedstawiono punktację za poszczególne realizowane funkcjonalności

### W projekcie:
- [X] eksport/import z pliku XML
- [X] eksport/import z pliku JSON/YAML
- [X] eksport/import z bazy danych
- [X] wykorzystanie ORM w celu dostępu do bazy danych
- [X] wykorzystanie usług typu SOAP
- [X] wykorzystanie usług typu REST
- [X] wykorzystanie kontenerów Docker
- [X] wykorzystanie mechanizmów uwierzytelnienia i autoryzacji przy użyciu tokenów JWT
- [X] wykorzystanie poziomów izolacji w bazie danych

# Wymagane technologie
Aplikacja web:
Laravel 10
Composer 2.5.8
PHP 8.2.4

Client Soap:
.NET 6

# Instrukcja instalacji
1. Rozpakuj projekt

2. Przejdź do katalogu projektu:
```
cd Project/project
```

3. Zainstaluj zależności Composer:
```
composer install
```

4. Skopiuj zawartość pliku `.env.example` do pliku `.env`:
```
cp .env.example .env
```

5. Wygeneruj klucz aplikacji:
```
php artisan key:generate
```

5.5. Wygeneruj Secret key
```
php artisan jwt:secret
```

6. Zainstaluj i skonfiguruj narzędzie Sail, które umożliwi uruchomienie kontenerów Dockera (należy wybrać mysql [0]):
```
php artisan sail:install
```

7. Wyczyść zbuforowane dane aplikacji, przed uruchomieniem kontenerów:
```
php artisan optimize:clear
```

8. Należy uruchomić aplikację:
```
./vendor/bin/sail up -d
```

9. Wyczyść już istniejące migracje
```
./vendor/bin/sail artisan migrate:fresh
```

9.5 Moze okazać się potrzeba zmiana uprawnień
```
chmod 777 -R *
```

10. Zamknięcie aplikacji (wewnątrz katalogu z projektem)
```
./vendor/bin/sail down
```
# Opis
Projekt przedstawia zestawienie danych o grach na platformach Steam i Epic Games Store. Umożliwia użytkownikom rejestracje, logowanie, import/export danych oraz wyświetlanie ich na stronie internetowej

Dane do projektu znajdują się w katalogu datasets. 
Należy zaimportować jeden z plików:
- games.csv,
- games.json,
- games.xml

Aby import/export był możliwy należy utworzyć konto. `Create an account` w sekcji login

Aplikacja działa na porcie `8000` więc adresem projektu jest `localhost:8000`