# Zestawienie danych statystycznych dotyczących gier na platformach Steam i Epic Games Store

## Projekt:
- realizowany w grupach dwuosobowych
- należy wykonać w technologiach przedstawionych w skrypcie
- należy zaprezentować prowadzącemu i przesłać w terminie do przedostatnich zajęć włącznie
- integrowane dane przechowywane w plikach lub bazie danych muszą być zgodne z tematyką projektu
- wymagany jest interfejs graficzny pozwalający na wykonywanie akcji oraz prezentację danych
- Poniżej przedstawiono punktację za poszczególne realizowane funkcjonalności

### W projekcie:
- [X] eksport/import z pliku XML – 5 pkt
- [X] eksport/import z pliku JSON/YAML – 5 pkt
- [X] eksport/import z bazy danych – 5 pkt
- [X] wykorzystanie ORM w celu dostępu do bazy danych – 5 pkt
- [X] wykorzystanie usług typu SOAP – 5 pkt
- [X] wykorzystanie usług typu REST – 5 pkt
- [X] wykorzystanie kontenerów Docker – 5 pkt
- [X] wykorzystanie mechanizmów uwierzytelnienia i autoryzacji przy użyciu tokenów JWT – 5 pkt
- [X] wykorzystanie poziomów izolacji w bazie danych – 5 pkt

# Instrukcja instalacji
1. Rozpakuj projekt

2. Przejdź do katalogu projektu:
```
cd Project/project
```

3. Zainstaluj zależności Composer:
```
composer install
```

4. Skopiuj zawartość pliku `.env.example` do pliku `.env`:
```
cp .env.example .env
```

5. Wygeneruj klucz aplikacji:
```
php artisan key:generate
```

6. Zainstaluj i skonfiguruj narzędzie Sail, które umożliwi uruchomienie kontenerów Dockera:
```
php artisan sail:install
```

7. Wyczyść zbuforowane dane aplikacji, przed uruchomieniem kontenerów:
```
php artisan optimize:clear
```

8. Wyczyść już istniejące migracje
```
./vendor/bin/sail artisan migrate:fresh
```

9. Wygeneruj Secret Key (JWT)
```
./vendor/bin/sail artisan key:generate
```

10. Uruchom kontenery Dockera przy użyciu polecenia:
```
./vendor/bin/sail up
```

# Opis
Projekt przedstawia zestawienie danych o grach na platformach Steam i Epic Games Store. Umożliwia użytkownikom rejestracje, logowanie, import/export danych oraz wyświetlanie ich na stronie internetowej

Dane do projektu znajdują się w katalogu datasets. 
Należy zaimportować jeden z plików:
- games.csv,
- games.json,
- games.xml

Aby import/export był możliwy należy utworzyć konto. `Create an account` w sekcji login